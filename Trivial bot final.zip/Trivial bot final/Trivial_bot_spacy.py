import spacy
from bs4 import BeautifulSoup
import urllib.request
from numpy import dot
from numpy.linalg import norm

# Language model setup

nlp = spacy.load("en")

# Tell the user to input the question

def ask():
  question = input("What is your question: ")
  print("Please wait\n\n")
  a = process(question)

# Process the question

def process(ques):
  ques = nlp(ques)
  tag=[]
  pos=[]
  tok=[]
  for token in ques:
    tag.append(str(token.tag_))
    pos.append(str(token.pos_))
    tok.append(str(token))

# Check validity of question

  if not "NOUN" in pos and not "PROPN" in pos:
    print("Invalid question","\nPlease try again")
    ask()
  if not "VERB" in pos:
    print("Invalid question","\nPlease try again")
    ask()
  if not "?"==tok[-1]:
    print("Invalid question","\nPlease check your punctuation and try again")
    ask()
  if not "WP" == tag[0] and not "WRB" == tag[0]:
    print("Invalid question","\nThe question type is wrong. Please try again")
    ask()
  if ques.ents == None:
    print("Invalid question","\n Sorry can't answer these types of questions.Please try again")
    ask()

# Token Identification

  qude = {"Type": "", "Tarsub": "", "Verb": ""}

# Question type details

  qude["Type"] = tok[0]

# Noun details

  sub = str(ques.ents)
  sub = sub.split(",")
  sub = sub[0].replace("the ","").replace("(","").replace(",","")
  qude["Tarsub"] = sub
  if qude["Tarsub"] == "":
    for token in ques:
      if token.tag_ == "NN" or token.tag_ == "NNP":
        if qude["Tarsub"] == "":
          qude["Tarsub"] = str(token)
        else:
          qude["Tarsub"] = qude["Tarsub"] + " " + str(token)

# Verb details

  if pos[-2] == "VERB":
    qude["Verb"] = tok[-2]
  else:
    for token in ques:
      if str(token.pos_) == "VERB":
        qude["Verb"] = str(token)
        break
  retrieval(qude)

# Retrieve answer

def retrieval(search):

# Configuring the url

  ext = search["Tarsub"]
  ext.replace(" ","_")
  url = "https://en.wikipedia.org/wiki/" + ext

# Checking the webpage exists

  try:
    urllib.request.urlretrieve(url)
  except urllib.error.HTTPError as err:
    if err.code == 404:
      print("Sorry, A Wikipedia page does not exist for " + search["Tarsub"] + "\n\nPlease insert a new question")
      ask()

# Converting the html to a sutible string

  page = urllib.request.urlopen(url)
  soup = BeautifulSoup(page, "html.parser").find("div", {"class" : "mw-parser-output"})
  for table in soup.find_all("table"):
    table.decompose()
  content = soup.get_text()
  content = content.split("\nContents\n",1)
  content = content[0]

# Finding suspect scentences through the verb.

  a1 = [sentence + "." for sentence in content.split(".") if search["Verb"] in sentence]
  if a1 != []:
    a1 = checker(search["Type"], a1, search["Tarsub"])
  if a1 == []:
    a1 = [sentence + "." for sentence in content.split(".") if search["Verb"].title() in sentence]
    if a1 != []:
      a1 = checker(search["Type"], a1, search["Tarsub"])
  if a1 == []:
    verb = search["Verb"]
    simil = nlp.vocab[verb]

# Cosine similarity

    cosine = lambda v1, v2: dot(v1, v2) / (norm(v1) * norm(v2))

# gather all known words, take only the lowercased versions and then check title versions.

    allWords = list({w for w in nlp.vocab if w.has_vector and w.orth_.islower() and w.lower_ != verb.lower()})
    allWords.sort(key=lambda w: cosine(w.vector, simil.vector))
    allWords.reverse()
    for word in allWords[:10]:
      a1 = [sentence + "." for sentence in content.split(".") if word.orth_ in sentence]
      if a1 != []:
        a1 = checker(search["Type"], a1, search["Tarsub"])
        if a1 != []:
          break
      if a1 == []:
        a1 = [sentence + "." for sentence in content.split(".") if word.orth_.title() in sentence]
      if a1 != []:
        a1 = checker(search["Type"], a1, search["Tarsub"])
        if a1 != []:
          break
      if a1 == []:
        print("No result found for your question")
        ask()

# Checks if there is a possible answer in suspect scentences

def checker(Type, sentence, subject):
  sub = subject
  b1 = ""

# Formatting the string

  for x in sentence:
    b1 += x.replace("\n","")
  for x in range(0,100):
    b1 = b1.replace("["+str(x)+"]","")
  b1.lstrip()
  b1nlp = nlp(b1)
  Answer = ""

# Find suspect answer through the entities of the suspect scentence

  if Type == "Who" :
    l = ["PERSON", "NORP", "ORG", "GPE"]
    for ent in b1nlp.ents:
      for x in l:
        if str(ent.label_) == x and str(ent) != sub and str(ent) != "the" + sub:
          Answer = str(ent).replace("the", "The")
          break
      if Answer != "":
        break
    if Answer == "":
      return []
  elif Type == "When":
    for ent in b1nlp.ents:
      if str(ent.label_) == "DATE":
        Answer = "In " + str(ent)
        break
      elif str(ent.label_) == "TIME":
        Answer = "At " + str(ent)
        break
    if Answer == "":
      return []
  elif Type == "Where":
    l = ["FACILITY", "ORG", "GPE", "LOC", "PRODUCT", "WORK_OF_ART"]
    for ent in b1nlp.ents:
      for x in l:
        if str(ent.label_) == x:
          if str(ent) != sub and str(ent) != "the" + sub:
            Answer = "In " + str(ent)
            break
      if Answer != "":
        break
    if Answer == "":
      return[]

# If question type is "Why" or "What" print all the suspect scentences

  else:
    Answer = b1
  if Type == "What" or Type == "Why":
    print("You might find your answer here: \n\n" + Answer)
    ask()
  else:
    print(Answer)
    ask()

# Initialization

if __name__ == "__main__" :
  ask()
